const verifyForm = document.getElementById('verifyForm');
const store = document.getElementById('store');
const verifyCard = document.getElementById('verify');
const verifiedFor = document.querySelector('#verifiedFor span');
const payModal = document.getElementById('payModal');
const modalText = document.getElementById('modalText');
const txnIdInput = document.getElementById('txnId');

// Simple verify -> show store
verifyForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const id = document.getElementById('playerId').value.trim();
  if(!/^[0-9]{5,20}$/.test(id)){
    alert('Please enter a valid numeric BGMI ID (5-20 digits).');
    return;
  }
  verifiedFor.textContent = id;
  verifyCard.classList.add('hidden');
  store.classList.remove('hidden');
  window.scrollTo({ top: 0, behavior: 'smooth' });
});

// Handle Buy buttons -> open modal
document.querySelectorAll('.buy').forEach(btn => {
  btn.addEventListener('click', () => {
    const pack = btn.dataset.pack;
    const amount = btn.dataset.amount;
    modalText.textContent = `You're purchasing ${pack} for ₹${amount}. Scan the QR to pay, then enter the transaction/UTR ID below.`;
    txnIdInput.value = '';
    payModal.showModal();
  });
});

// Handle confirm
document.getElementById('confirmBtn').addEventListener('click', (e) => {
  e.preventDefault();
  const txn = txnIdInput.value.trim();
  if(txn.length < 6){
    alert('Please enter a valid transaction/UTR ID.');
    return;
  }
  payModal.close('confirm');
  alert('Thanks! Your payment reference was submitted. This is a demo page — connect it to your backend for real processing.');
});
