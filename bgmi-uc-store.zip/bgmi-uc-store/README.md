# BGMI UC Store (Demo)

This project recreates the layout you shared:

- The page **begins with verifying character ID** (BGMI ID).
- After a valid ID is entered, it shows the **same UC packs and prices** as in your screenshot:
  - 5000 UC — ₹1000
  - 15000 UC — ₹2000
  - 25000 UC — ₹2500
  - 50000 UC — ₹4500
  - 100000 UC — ₹5000
- The **second image (UC coins)** is used on every price card.
- The **first image** is used as the **full‑page background**.
- The **QR code image** is used in the payment modal and in the Payment section.

## Files
- `index.html` — markup
- `style.css` — styles
- `script.js` — interactions (verify, modal)
- `img/` — all images you provided

> This is a front‑end demo — to actually verify payments, hook the modal “Submit” action to your server or payment gateway webhooks.
